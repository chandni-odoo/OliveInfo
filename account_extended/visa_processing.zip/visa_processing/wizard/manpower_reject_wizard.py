from odoo import models, fields, api

class ManpowerRequisitionReject(models.TransientModel):
    _name = 'manpower.requisition.reject'
    _description = 'Reject Manpower Requisition'

    reject_reason = fields.Text(string='Rejection Reason', required=True)
    
    def action_confirm_reject(self):
        active_id = self.env.context.get('active_id')
        active_model = self.env.context.get('active_model', 'manpower.requisition')
        
        if not active_id:
            return {'type': 'ir.actions.act_window_close'}
            
        requisition = self.env[active_model].browse(active_id)
        
        if requisition:
            requisition.write({'reject_reason': self.reject_reason})
            requisition.action_reject()
            
        return {'type': 'ir.actions.act_window_close'}