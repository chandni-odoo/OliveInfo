{
    'name': 'Payroll Reports',
    'summary': "Hr Payroll Report",
    'description': "Payroll Reports",
    'category': 'Payslip',
    'version': '15.0.0',
    'author': 'Olive Infocraft Trading LLC',
    'depends': ['base','hr', 'base','hr_payroll','report_xlsx','hr_contract','branch','hr_payroll_account','hr_payroll_extended','hr_extended'],
    'data': [
        'security/ir.model.access.csv',
        'reports/report_template.xml',
        'reports/contract_report_template.xml',
        'views/hr_payslip.xml',
        'wizard/payroll_wizard_views.xml',
        'wizard/contract_wizard_views.xml',
    ],

    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
