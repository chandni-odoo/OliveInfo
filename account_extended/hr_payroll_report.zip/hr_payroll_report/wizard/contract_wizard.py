from odoo import models, fields, api

class ContractReportWizard(models.TransientModel):
    _name = 'contract.report.wizard'
    _description = 'HR Contract Salary Report Wizard'

    branch_ids = fields.Many2many('res.branch', string="Branch")
    billable = fields.Boolean("Billable Only")
    employee_status = fields.Selection([
        ('active', 'Active'),
        ('off_hire', 'Off Hire'),
        ('leave', 'Leave'),
        ('deceased', 'Deceased'),
        ('retired', 'Retired'),
        ('absconded', 'Absconded'),
        ('resigned', 'Resigned'),
        ('terminated', 'Terminated'),
        ('layoff', 'Layoff'),
        ('long_leave', 'Long Leave Absconder'),
        ('onboarding', 'Onboarding'),
        ('employer_change', 'Employer Change')
    ], string="Employee Status")
    hide_zero_records = fields.Boolean("Hide Zero Records", default=True)

    def action_generate_report(self):
        return self.env.ref('hr_payroll_report.action_contract_salary_report').report_action(self)