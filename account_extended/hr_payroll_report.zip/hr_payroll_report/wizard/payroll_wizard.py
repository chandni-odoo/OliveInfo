from odoo import models, fields, api


class PayslipReportWizard(models.TransientModel):
    _name = 'payslip.report.wizard'
    _description = 'Payroll Report Wizard'

    date_to = fields.Date("Payroll Date", required=True)
    payslip_batch_id = fields.Many2one('hr.payslip.run', string="Payroll Batch")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('verify', 'Waiting'),
        ('done', 'Done'),
        ('paid', 'Paid'),
        ('cancel', 'Rejected')],
        string='Status',
        default='done')

    def action_generate_report(self):
        data = {
            'date_to': self.date_to.strftime('%Y-%m-%d') if self.date_to else False,
            'payslip_batch_id': self.payslip_batch_id.id if self.payslip_batch_id else False,
            'payslip_batch_name': self.payslip_batch_id.name if self.payslip_batch_id else False,
            'state': self.state,
        }
        return self.env.ref('hr_payroll_report.action_employee_payroll_report').report_action(self, data=data)

