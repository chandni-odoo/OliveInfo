from odoo import models, fields

class HrPayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    reporting_account_id = fields.Many2one('account.account',string='Reporting Account')

