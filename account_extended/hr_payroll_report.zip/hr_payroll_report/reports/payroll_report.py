from odoo import models, fields, api
from datetime import datetime

from odoo import models
from datetime import datetime
from odoo.tools import date_utils

class PayslipReport(models.AbstractModel):
    _name = 'report.hr_payroll_report.payslip_report_xlsx'
    _inherit = 'report.report_xlsx.abstract'
    _description = 'Payroll Report'

    def generate_xlsx_report(self, workbook, data, lines):
        date_to = data.get('date_to')
        payslip_batch_id = data.get('payslip_batch_id')
        state = data.get('state', 'done')

        if isinstance(date_to, str):
            date_to = datetime.strptime(date_to, '%Y-%m-%d').date()

        domain = [
            ('date_to', '=', date_to),  
            ('state', '=', state)      
        ]
        
        if payslip_batch_id:
            domain.append(('payslip_run_id', '=', payslip_batch_id))
        
        slips = self.env['hr.payslip'].search(domain, order='employee_id, date_from')

        sheet = workbook.add_worksheet('Employee Payroll Report')
        
        header_format = workbook.add_format({
            'bold': True,
            'align': 'center',
            'valign': 'vcenter',
            'bg_color': '#4472C4',
            'font_color': 'white',
            'border': 1
        })
        
        data_format = workbook.add_format({
            'border': 1,
            'align': 'left',
            'valign': 'top'
        })
        
        number_format = workbook.add_format({
            'border': 1,
            'num_format': '#,##0.00',
            'align': 'right'
        })
        
        headers = [
            'Emp. No.', 'Name', 'Branch', 
            'Batch', 'Salary Component', 
            'Amount', 'Employee Group', 'Debit Account'
        ]
        
        for col, header in enumerate(headers):
            sheet.write(0, col, header, header_format)
            if col in [1, 2, 3, 4, 7]:  
                sheet.set_column(col, col, 25)
            else:
                sheet.set_column(col, col, 15)
        
        row = 1
        total_lines_processed = 0
        
        for slip in slips:
            emp = slip.employee_id  
            
            # Get employee details
            emp_no = emp.emp_no or '' 
            emp_name = emp.name or ''
            # branch = emp.branch_id.name if hasattr(emp, 'branch_id') and emp.branch_id else ''

            branch = ''
            if hasattr(emp, 'branch_id') and emp.branch_id:
                branch_code = emp.branch_id.code or ''
                branch_name = emp.branch_id.name or ''
                if branch_code and branch_name:
                    branch = f"{branch_code} - {branch_name}"
                else:
                    branch = branch_code or branch_name
            
            # Get employee group/category
            emp_group = ''
            if hasattr(emp, 'category_ids') and emp.category_ids:
                emp_group = ', '.join(emp.category_ids.mapped('name'))
            elif hasattr(emp, 'employee_group_id') and emp.employee_group_id:
                emp_group = emp.employee_group_id.name
            
            # Get batch name
            batch_name = slip.payslip_run_id.name if slip.payslip_run_id else ''
            
            # Process payslip lines
            for line in slip.line_ids:
                # Skip zero amount lines
                if abs(line.total) < 0.01:
                    continue
                
                # Skip specific codes if needed
                skip_codes = ['GROSS', 'NET']
                if line.code and line.code.upper() in skip_codes:
                    continue

                # Get reporting account
                reporting_account = ''

                # First try to get from payslip structure
                if slip.struct_id and slip.struct_id.reporting_account_id:
                    reporting_account = f"{slip.struct_id.reporting_account_id.code} {slip.struct_id.reporting_account_id.name}"
                # Then check the line's reporting account if exists
                elif hasattr(line, 'reporting_account_id') and line.reporting_account_id:
                    reporting_account = f"{line.reporting_account_id.code} {line.reporting_account_id.name}"
                # Then check salary rule accounts
                elif line.salary_rule_id:
                    rule = line.salary_rule_id
                    if hasattr(rule, 'account_debit') and rule.account_debit:
                        reporting_account = f"{rule.account_debit.code} {rule.account_debit.name}"
                    elif hasattr(rule, 'account_credit') and rule.account_credit:
                        reporting_account = f"{rule.account_credit.code} {rule.account_credit.name}"

                # Write data to Excel
                sheet.write(row, 0, emp_no, data_format)
                sheet.write(row, 1, emp_name, data_format)
                sheet.write(row, 2, branch, data_format)
                sheet.write(row, 3, batch_name, data_format)
                sheet.write(row, 4, line.name or '', data_format)
                sheet.write(row, 5, line.total, number_format)
                sheet.write(row, 6, emp_group, data_format)
                sheet.write(row, 7, reporting_account, data_format)
                
                row += 1
                total_lines_processed += 1
        
        # If no data found, add a message
        if total_lines_processed == 0:
            sheet.merge_range(1, 0, 1, 7, 
                f'No data found for payroll date {date_to} with status {state}. Please check your filters.', 
                data_format)


# class PayslipReport(models.AbstractModel):
#     _name = 'report.hr_payroll_report.payslip_report_xlsx'
#     _inherit = 'report.report_xlsx.abstract'
#     _description = 'Payroll Report'

#     def generate_xlsx_report(self, workbook, data, lines):
    
#         date_to = data.get('date_to')
#         payslip_batch_id = data.get('payslip_batch_id')

#         if isinstance(date_to, str):
#             date_to = datetime.strptime(date_to, '%Y-%m-%d').date()

#         domain = [
#             ('date_to', '<=', date_to),  
#             ('state', 'in', ['done'])
#         ]
        
#         if payslip_batch_id:
#             domain.append(('payslip_run_id', '=', payslip_batch_id))
        
#         slips = self.env['hr.payslip'].search(domain, order='employee_id, date_from')

#         sheet = workbook.add_worksheet('Employee Payroll Report')
        
#         header_format = workbook.add_format({
#             'bold': True,
#             'align': 'center',
#             'valign': 'vcenter',
#             'bg_color': '#4472C4',
#             'font_color': 'white',
#             'border': 1
#         })
        
#         data_format = workbook.add_format({
#             'border': 1,
#             'align': 'left',
#             'valign': 'top'
#         })
        
#         number_format = workbook.add_format({
#             'border': 1,
#             'num_format': '#,##0.00',
#             'align': 'right'
#         })
        
#         headers = [
#             'Employee ID', 'Employee Name', 'Branch', 
#             'Payroll Batch', 'Component Name', 
#             'Amount', 'Employee Group', 'Reporting Account'
#         ]
        
#         for col, header in enumerate(headers):
#             sheet.write(0, col, header, header_format)
#             # Set column widths
#             if col in [1, 2, 3, 4, 7]:  # Wider columns for text
#                 sheet.set_column(col, col, 25)
#             else:
#                 sheet.set_column(col, col, 15)
        
#         row = 1
#         total_lines_processed = 0
        
#         for slip in slips:
#             emp = slip.employee_id  # This is the hr.employee record
            
#             # Get employee details
#             emp_code = emp.barcode or emp.identification_id or str(emp.id)  # Use barcode, identification_id, or ID
#             emp_name = emp.name or ''
#             branch = emp.branch_id.name if hasattr(emp, 'branch_id') and emp.branch_id else ''
            
#             # Get employee group/category
#             emp_group = ''
#             if hasattr(emp, 'category_ids') and emp.category_ids:
#                 emp_group = ', '.join(emp.category_ids.mapped('name'))
#             elif hasattr(emp, 'employee_group_id') and emp.employee_group_id:
#                 emp_group = emp.employee_group_id.name
            
#             # Get batch name
#             batch_name = slip.payslip_run_id.name if slip.payslip_run_id else ''
            
#             # Process payslip lines
#             for line in slip.line_ids:
#                 # Skip zero amount lines
#                 if abs(line.total) < 0.01:
#                     continue
                
#                 # Skip specific codes if needed
#                 skip_codes = ['GROSS', 'NET']
#                 if line.code and line.code.upper() in skip_codes:
#                     continue

#                 # Get reporting account
#                 reporting_account = ''

#                 # First try to get from payslip structure
#                 if slip.struct_id and slip.struct_id.reporting_account_id:
#                     reporting_account = f"{slip.struct_id.reporting_account_id.code} {slip.struct_id.reporting_account_id.name}"
#                 # Then check the line's reporting account if exists
#                 elif hasattr(line, 'reporting_account_id') and line.reporting_account_id:
#                     reporting_account = f"{line.reporting_account_id.code} {line.reporting_account_id.name}"
#                 # Then check salary rule accounts
#                 elif line.salary_rule_id:
#                     rule = line.salary_rule_id
#                     if hasattr(rule, 'account_debit') and rule.account_debit:
#                         reporting_account = f"{rule.account_debit.code} {rule.account_debit.name}"
#                     elif hasattr(rule, 'account_credit') and rule.account_credit:
#                         reporting_account = f"{rule.account_credit.code} {rule.account_credit.name}"

                
#                 # Write data to Excel
#                 sheet.write(row, 0, emp_code, data_format)
#                 sheet.write(row, 1, emp_name, data_format)
#                 sheet.write(row, 2, branch, data_format)
#                 sheet.write(row, 3, batch_name, data_format)
#                 sheet.write(row, 4, line.name or '', data_format)
#                 sheet.write(row, 5, line.total, number_format)
#                 sheet.write(row, 6, emp_group, data_format)
#                 sheet.write(row, 7, reporting_account, data_format)
                
#                 row += 1
#                 total_lines_processed += 1
        
#         # If no data found, add a message
#         if total_lines_processed == 0:
#             sheet.merge_range(1, 0, 1, 7, 
#                 f'No data found up to {date_to}. Please check your date range and payslip status.', 
#                 data_format)

